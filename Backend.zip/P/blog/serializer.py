from rest_framework.serializers import ModelSerializer
from .models import Tags, Artykul

class ArtykulSerializer(ModelSerializer):
    class Meta: 
        model = Artykul 
        fields = ['id', 'tags', 'tytul', 'streszczenie','tresc', 'data']


class TagsSerializer(ModelSerializer):
    class Meta:
        model = Tags
        fields = ['id','nazwa']