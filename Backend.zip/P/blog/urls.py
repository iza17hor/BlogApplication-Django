from django.urls import path

from rest_framework import routers

from .views import * # skonfigurowanie z router, tworzą nowe adresy url

router = routers.DefaultRouter()
router.register('artykul',ArtykulViewSet)
router.register('tags',TagsViewSet)


urlpatterns = router.urls # wykorzytsanie listy adresów, zwrócic liste, ta lista bedzie wykorzytana na mapowanie adresów url na klasy widoków