from django.db import models

class Tags(models.Model):
        nazwa=models.CharField(max_length=200, null=True)
        

        def __str__(self):
            return self.nazwa


class Artykul(models.Model):


        tytul=models.CharField(max_length=100, null=True)
        tags=models.ManyToManyField('Tags')
        streszczenie=models.CharField(max_length=2000, null=True)
        tresc=models.CharField(max_length=5000, null=True)
        data=models.DateTimeField(auto_now_add= True, null=True)

        def __str__(self):
            return self.tytul

        class Meta:
                ordering = ['data']