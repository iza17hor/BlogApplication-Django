
from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet
from .models import Artykul, Tags
from .serializer import ArtykulSerializer, TagsSerializer
from rest_framework.permissions import IsAuthenticatedOrReadOnly



class ArtykulViewSet(ModelViewSet): 
    queryset = Artykul.objects.all()
    serializer_class = ArtykulSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]

class TagsViewSet(ModelViewSet): 
    queryset = Tags.objects.all()
    serializer_class = TagsSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]

