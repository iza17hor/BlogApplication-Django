from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager

class UserManager(BaseUserManager):
    def create_user(self, email, password, **kwargs): #forma jawna
        user = self.model(email=email, **kwargs)
        user.set_password(password) # metoda do szyfrowania hasła
        user.is_active = True
        user.save() #zapisywanie 
        return user

#**kwargs- inne parametry które mogły zostać przekazane

    def create_superuser (self, email, password, **kwargs):
        return self.create_user(email, password, is_superuser=True, **kwargs)

class User(AbstractBaseUser):
    email =models.EmailField('Email', unique=True) #z kazdym uzytkownikiem powiązany jest jeden adres email w bazie danych
    first_name = models.CharField('Imie', max_length=120)
    last_name = models.CharField('nazwisko', max_length=120)
    is_active = models.BooleanField ('Czy aktywny', default=False)
    is_superuser = models.BooleanField ('Czy admin?', default=False)
    is_staff = models.BooleanField(default=True)
    

    EMAIL_FIELD ='email'
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['first_name', 'last_name']

    objects = UserManager()
